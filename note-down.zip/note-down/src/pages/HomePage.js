import { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import PropType from 'prop-types';
import Auth from '../components/Auth';
import Header from '../components/common/Header';
import NotesView from '../components/NotesView';
import CategoriesTabList from '../components/CategoriesTabList';
import firebaseConfig from '../configs/firebaseConfig';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import BottomTabList from '../components/BottomTabList';
import { ErrorBoundary as SentryErrorBoundary } from '@sentry/react';
import { notesAction } from '../store/actions/notesAction';
const callAllFuncs =
	(...funcs) =>
	(...args) =>
		funcs.forEach(func => func && func(...args));
function HomePage(props) {
	const { isLoggedIn, getNoteCategories, getNotes } = props;
	const [firebaseInitialized, setFirebaseInitialized] = useState(false);
	const setupFirestoreEventListener = useCallback(async () => {
		const isFirebaseInitialized = await firebaseConfig.isInitialized();
		if (isFirebaseInitialized) {
			const categoryDocRef = firebaseConfig.createDocRef(
				'app/users',
				`${firebaseConfig.auth.currentUser.uid}/categories`,
			);
			const noteDocRef = firebaseConfig.createDocRef(
				'app/users',
				`${firebaseConfig.auth.currentUser.uid}/notes`,
			);
			const unSubscribeFromOnSnapshotOfCategory =
				firebaseConfig.onSnapshot(categoryDocRef, getNoteCategories);
			const unSubscribeFromOnSnapshotOfNotes = firebaseConfig.onSnapshot(
				noteDocRef,
				getNotes,
			);
			return [
				unSubscribeFromOnSnapshotOfCategory,
				unSubscribeFromOnSnapshotOfNotes,
			];
		}
	}, [getNotes, getNoteCategories]);

	useEffect(() => {
		let cleanupFunc;
		setupFirestoreEventListener()
			.then(cleanupFuncs => {
				if (cleanupFuncs) {
					cleanupFunc = callAllFuncs(...cleanupFuncs);
					setFirebaseInitialized(true);
					setTakingLongTimeToLoadText(',');
				}
			})
			.catch(err =>
				console.log('An error occurred while initiation of firebase'),
			);
		return () => callAllFuncs && cleanupFunc();
	}, [setupFirestoreEventListener]);
	const [takingLongTimeToLoadText, setTakingLongTimeToLoadText] =
		useState(',');
	useEffect(() => {
		let timeout = setTimeout(() => {
			setTakingLongTimeToLoadText(
				'It is taking more time to load, may be your network speed is slow',
			);
		}, 2000);
		return () => clearTimeout(timeout);
	});
	return (
		<>
			{shouldShowAuthPage(isLoggedIn) && <Auth />}
			{!shouldShowAuthPage(isLoggedIn) && (
				<>
					{firebaseInitialized && (
						<>
							<SentryErrorBoundary
								fallback={
									<p>Error occurred while getting profile</p>
								}
							>
								<Header />
							</SentryErrorBoundary>
							<SentryErrorBoundary
								fallback={
									<p>
										An error occurred. Please clear your
										cache and try again{' '}
									</p>
								}
							>
								<CategoriesTabList />
								<NotesView />
								<BottomTabList />
							</SentryErrorBoundary>
						</>
					)}
					{!firebaseInitialized && (
						<Box
							sx={{
								height: '100vh',
								display: 'flex',
								flexDirection: 'column',
								justifyContent: 'center',
								alignItems: 'center',
								gap: '16px',
							}}
						>
							<CircularProgress color='secondary' size={100} />
							<Box
								component={'div'}
								sx={{
									display: 'flex',
									flexDirection: 'column',
									justifyContent: 'center',
									alignItems: 'center',
								}}
							>
								<Typography variant='caption'>
									{takingLongTimeToLoadText.split(',')[0]}
									{','}
								</Typography>
								<Typography variant='caption'>
									{takingLongTimeToLoadText.split(',')[1]}
									{'.'}
								</Typography>
							</Box>
						</Box>
					)}
				</>
			)}
		</>
	);
}
function mapToState(state) {
	const { userReducer } = state;
	const { isLoggedIn } = userReducer;
	return {
		isLoggedIn,
	};
}
const mapToDispatch = {
	getNoteCategories: notesAction.getNoteCategories,
	getNotes: notesAction.getNotes,
};
export default connect(mapToState, mapToDispatch)(HomePage);

function shouldShowAuthPage(isLoggedIn) {
	if (isLoggedIn) return false;
	return true;
}

HomePage.propTypes = {
	isLoggedIn: PropType.bool,
	getNoteCategories: PropType.func.isRequired,
	getNotes: PropType.func.isRequired,
};
