import { useEffect, useState } from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Link from '@mui/material/Link';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import ListSubheader from '@mui/material/ListSubheader';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import { Divider } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import Tooltip from '@mui/material/Tooltip';
import * as yup from 'yup';
import OneFieldFormPopup from '../components/OneFieldFormPopup';
import { connect } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import LoadingButton from '@mui/lab/LoadingButton';
import { userActions } from '../store/actions/userActions';
import { authServices } from '../services/authServices';
import { styled } from '@mui/material/styles';
import IconButton from '@mui/material/IconButton';
import CircularProgress from '@mui/material/CircularProgress';
import PropTypes from 'prop-types';
const Input = styled('input')({
	display: 'none',
});
const validationSchema = yup.object({
	value1: yup
		.string('Enter your full name')
		.trim(' ')
		.min(2, 'Name must be more than two character')
		.required(`Name can't be empty`),
});
function ProfilePage(props) {
	const {
		updateDisplayName,
		signOut,
		updateDisplayPhoto,
		displayName,
		email,
		emailVerified,
		photoURL,
	} = props;
	const [shouldShowRenameDisplayNamePopup, setRenameDisplayNamePopup] =
		useState(false);
	const [loadingStateOfDisplayBtn, setLoadingStateOfDisplayBtn] =
		useState(false);
	const [loadingStateOfDisplayPhoto, setLoadingStateOfDisplayPhoto] =
		useState(false);
	const [emailVerificationSentText, setEmailVerificationSentText] =
		useState('');
	const OnCloseHandlerOFRenameDisplayNamePopup = async (
		isCanceled,
		updatedName,
	) => {
		setRenameDisplayNamePopup(false);
		if (isCanceled) return;
		setLoadingStateOfDisplayBtn(true);
		updateDisplayName(updatedName);
	};
	const sendEmailVerificationEmail = () => {
		authServices.sendEmailVerification();
		setEmailVerificationSentText('Email verification email sent.');
	};
	useEffect(() => {
		setLoadingStateOfDisplayBtn(false);
	}, [displayName]);
	useEffect(() => {
		setLoadingStateOfDisplayPhoto(false);
	}, [photoURL]);
	let navigate = useNavigate();
	const logoutHandler = () => {
		navigate('/');
		signOut();
	};
	const uploadDP = file => {
		setLoadingStateOfDisplayPhoto(true);
		updateDisplayPhoto(file);
	};

	return (
		<>
			<Box
				sx={{
					display: 'flex',
					flexDirection: 'column',
					minHeight: '100vh',
				}}
			>
				<CssBaseline />
				<ArrowBackIcon
					sx={{ fontSize: 40, mt: 2, ml: 1, cursor: 'pointer' }}
					onClick={() => navigate('/')}
				/>
				<Container component='main' sx={{ mt: 8, mb: 2 }} maxWidth='sm'>
					<Box
						sx={{
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'center',
							alignItems: 'center',
						}}
					>
						<label htmlFor='icon-button-file'>
							<Input
								accept='image/*'
								id='icon-button-file'
								type='file'
								onChange={e => uploadDP(e.target.files[0])}
							/>
							<IconButton
								color='primary'
								aria-label='upload picture'
								component='span'
							>
								{!loadingStateOfDisplayPhoto && (
									<Avatar
										alt={displayName}
										src={photoURL}
										{...stringAvatar(displayName)}
									/>
								)}
								{loadingStateOfDisplayPhoto && (
									<CircularProgress color='secondary' />
								)}
							</IconButton>
						</label>
						<LoadingButton
							loading={loadingStateOfDisplayBtn}
							variant='text'
							color='secondary'
							component='div'
							endIcon={<ModeEditIcon />}
							onClick={() => setRenameDisplayNamePopup(true)}
						>
							{displayName ?? 'Name is not set'}
						</LoadingButton>
					</Box>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							flexWrap: 'wrap',
						}}
					>
						<Typography
							variant='button'
							component='div'
							sx={{
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',
							}}
						>
							Email:{' '}
						</Typography>
						<Button
							variant='text'
							color='secondary'
							component='div'
							endIcon={
								emailVerified ? (
									<Tooltip title='Email is verified' arrow>
										<CheckCircleRoundedIcon color='success' />
									</Tooltip>
								) : (
									<Tooltip
										title='Email is not verified'
										arrow
									>
										<CancelRoundedIcon color='error' />
									</Tooltip>
								)
							}
							sx={{ textTransform: 'lowercase' }}
						>
							{' '}
							{email}
						</Button>
						{!emailVerified && (
							<Button
								variant='text'
								color='secondary'
								component='div'
								onClick={sendEmailVerificationEmail}
								disabled={
									emailVerificationSentText ? true : false
								}
							>
								Verify
							</Button>
						)}
					</Box>
					<Typography
						variant='caption'
						align='center'
						display='block'
					>
						{emailVerificationSentText}
					</Typography>
					<Box maxWidth='xs'>
						<Button
							type='submit'
							fullWidth
							variant='contained'
							sx={{ mt: 6, mb: 2 }}
							color='secondary'
							onClick={logoutHandler}
						>
							Logout
						</Button>
					</Box>
				</Container>
				<Box
					component='footer'
					sx={{
						mt: 'auto',
						backgroundColor: theme =>
							theme.palette.mode === 'light'
								? theme.palette.grey[200]
								: theme.palette.grey[800],
					}}
				>
					<Container
						maxWidth='sm'
						sx={{
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'center',
							alignItems: 'center',
						}}
					>
						<List
							sx={{
								width: '100%',
								maxWidth: 'xs',
								bgcolor: 'inherit',
							}}
							component='nav'
							aria-labelledby='nested-list-subheader'
							subheader={
								<>
									<ListSubheader
										component='div'
										id='nested-list-subheader'
										sx={{ bgcolor: 'inherit' }}
									>
										Credits:-
									</ListSubheader>
									<Divider />
								</>
							}
						>
							<ListItemButton>
								<Link
									color='inherit'
									href='https://www.flaticon.com/free-icons/survey'
									title='survey icons'
								>
									Survey icons created by Freepik - Flaticon
								</Link>
							</ListItemButton>
						</List>
						<Link color='inherit' href='https://node-down.web.app/'>
							Buy a cup of coffee for developer
						</Link>
						<Copyright />
					</Container>
				</Box>
				<OneFieldFormPopup
					open={shouldShowRenameDisplayNamePopup}
					onCloseHandler={OnCloseHandlerOFRenameDisplayNamePopup}
					initialValues={displayName}
					shouldTakeInitialValue={true}
					validationSchema={validationSchema}
					fieldLabel={'Enter Your Full Name'}
					popupHeading={'Edit'}
					popupBodyText={
						'Please enter the update name and hit the save option'
					}
				/>
			</Box>
		</>
	);
}
function mapToState(state) {
	const { userReducer } = state;
	const { userData } = userReducer;
	const { displayName, email, emailVerified, photoURL } = userData;
	return {
		displayName,
		email,
		emailVerified,
		photoURL,
	};
}

const mapToDispatch = {
	updateDisplayName: userActions.updateDisplayName,
	signOut: userActions.signOut,
	updateDisplayPhoto: userActions.updateDisplayPhoto,
};
export default connect(mapToState, mapToDispatch)(ProfilePage);

ProfilePage.propTypes = {
	displayName: PropTypes.string,
	email: PropTypes.string.isRequired,
	emailVerified: PropTypes.bool.isRequired,
	photoURL: PropTypes.string,
};

function stringToColor(string) {
	let hash = 0;
	let i;

	/* eslint-disable no-bitwise */
	for (i = 0; i < string.length; i += 1) {
		hash = string.charCodeAt(i) + ((hash << 5) - hash);
	}

	let color = '#';

	for (i = 0; i < 3; i += 1) {
		const value = (hash >> (i * 8)) & 0xff;
		color += `00${value.toString(16)}`.substr(-2);
	}
	/* eslint-enable no-bitwise */

	return color;
}

function stringAvatar(name = 'U N') {
	const firstLetterOfFirstName = name.split(' ')[0][0];
	let firstLetterOfLastName = '';
	if (name.split(' ').length > 1) {
		firstLetterOfLastName = name.split(' ')[1][0];
	} else {
		firstLetterOfLastName = name.split(' ')[0][1];
	}
	return {
		sx: {
			bgcolor: stringToColor(name),
			m: 1,
		},
		children: `${firstLetterOfFirstName}${firstLetterOfLastName}`,
	};
}
function Copyright() {
	return (
		<>
			<Box sx={{ display: 'flex', gap: '16px' }}>
				<Typography variant='body2' color='text.secondary'>
					{'Copyright © '}
					<Link color='inherit' href='https://node-down.web.app/'>
						Note Down
					</Link>{' '}
					{new Date().getFullYear()}
					{'.'}
				</Typography>
				<Typography variant='body2' color='text.secondary'>
					<Link color='inherit' href='https://node-down.web.app/'>
						Feedback
					</Link>
				</Typography>
			</Box>
		</>
	);
}
