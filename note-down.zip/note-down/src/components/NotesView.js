import { Fragment } from 'react';
import { connect } from 'react-redux';
import NoteItemView from './NoteItemView';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import PropTypes from 'prop-types';
import NoteCompletedAccordion from './common/NoteCompletedAccordion';
import NoNotesScreen from './NoNotesScreen';
import { filterNoteItemsByState,filterNoteItemsByCategory } from '../helper/commonFunctions';
function NotesView(props) {
	const {
		notesCatagoriesList,
		allNotes,
		sortBy,
		currentSelectedNoteCategoryIndex,
	} = props;
	return (
		<>
			{filterNoteItemsByCategory(
				allNotes,
				notesCatagoriesList[currentSelectedNoteCategoryIndex]?.id,
			).length === 0 && <NoNotesScreen />}
			<List
				sx={{ marginTop: 1, paddingRight: '16px', paddingLeft: '16px' }}
			>
				{allNotes &&
					filterNoteItemsByState(
						allNotes,
						'active',
						notesCatagoriesList[currentSelectedNoteCategoryIndex]
							?.id,
						sortBy,
					).map((noteItem, index) => {
						let props = {
							labelId: `checkbox-list-label-${index}`,
							note: noteItem,
						};
						return (
							<Fragment key={noteItem?.id + 'key'}>
								<NoteItemView {...props} />
							</Fragment>
						);
					})}
			</List>
			{filterNoteItemsByState(
				allNotes,
				'completed',
				notesCatagoriesList[currentSelectedNoteCategoryIndex]?.id,
			)?.length > 0 && (
				<>
					<Divider />
					<NoteCompletedAccordion
						completedNotes={filterNoteItemsByState(
							allNotes,
							'completed',
							notesCatagoriesList[
								currentSelectedNoteCategoryIndex
							]?.id,
							sortBy,
						)}
					/>
				</>
			)}
			
		</>
	);
}

function mapToState(state) {
	const { notesReducers } = state;
	const {
		notesCatagoriesList,
		allNotes,
		sortBy,
		currentSelectedNoteCategoryIndex,
	} = notesReducers;
	return {
		notesCatagoriesList,
		allNotes,
		sortBy,
		currentSelectedNoteCategoryIndex,
	};
}


export default connect(mapToState)(NotesView);
NotesView.propTypes = {
	notesCatagoriesList: PropTypes.arrayOf(PropTypes.object).isRequired,
	allNotes: PropTypes.arrayOf(PropTypes.object).isRequired,
	sortBy: PropTypes.string,
	currentSelectedNoteCategoryIndex: PropTypes.number.isRequired,
};


