import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import React from 'react';
export default function OneFieldFormPopup(props) {
	const {
		open,
		onCloseHandler,
		initialValues,
		shouldTakeInitialValue,
		validationSchema,
		fieldLabel,
		popupHeading,
		popupBodyText,
	} = props;
	const [update, setUpdate] = React.useState(0);
	const formik = useFormik({
		initialValues: {
			value1: initialValues || '',
		},
		validationSchema: validationSchema,
		onSubmit: values => {
			onCloseHandler(false, values.value1);
			formik.resetForm();
		},
	});
	const onCancelHandler = () => {
		formik.resetForm();
		onCloseHandler(true);
	};
	React.useEffect(() => {
		if (shouldTakeInitialValue) {
			formik.values.value1 = initialValues;
		} else {
			formik.values.value1 = '';
		}
		setUpdate(update + 1);
	}, [shouldTakeInitialValue, initialValues]);
	return (
		<div>
			<Dialog
				open={open}
				onClose={() => onCloseHandler(true)}
				component='form'
				onSubmit={formik.handleSubmit}
			>
				<DialogTitle color='secondary'>{popupHeading}</DialogTitle>
				<DialogContent>
					<DialogContentText color='secondary'>
						{popupBodyText}
					</DialogContentText>
					<TextField
						autoFocus
						margin='dense'
						label={fieldLabel}
						id='value1'
						type='text'
						fullWidth
						variant='standard'
						color='secondary'
						value={formik.values.value1}
						onChange={formik.handleChange}
						error={
							formik.value1&&
							Boolean(formik.errors.value1)
						}
						helperText={
							formik.touched.value1 &&
							formik.errors.value1
						}
					/>
				</DialogContent>
				<DialogActions>
					<Button onClick={() => onCancelHandler()} color='secondary'>
						Cancel
					</Button>
					<Button type='submit' color='secondary'>
						Save
					</Button>
				</DialogActions>
			</Dialog>
		</div>
	);
}
OneFieldFormPopup.propTypes = {
	open: PropTypes.bool.isRequired,
	onCloseHandler: PropTypes.func.isRequired,
	validationSchema: PropTypes.object.isRequired,
};
