import { useState } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types';
import AddIcon from '@mui/icons-material/Add';
import OneFieldFormPopup from './OneFieldFormPopup';
import { connect } from 'react-redux';
import { notesServices } from '../services/notesServices';
import { v4 as uuidv4 } from 'uuid';
import { notesAction } from '../store/actions/notesAction';
import * as yup from 'yup';
const validationSchema = yup.object({
	value1: yup
		.string('Enter category name')
		.min(2, 'Category name should be of minimum 2 characters length')
		.required('Category name is required'),
});
function CategoriesTabList(props) {
	const {
		notesCatagoriesList,
		currentSelectedNoteCategoryIndex,
		setCurrentSelectedNoteCategoryIndex,
	} = props;
	const [shouldShowAddCategoryPopup, setAddCategoryPopupState] =
		useState(false);
	const addCategoryPopupHandler = (isCancel, categoryName) => {
		setAddCategoryPopupState(false);
		if (isCancel) {
			currentActiveCategoryIndexHandler(null, 0);
			return;
		}
		const payload = {
			name: categoryName,
			id: uuidv4(),
		};
		notesServices.saveNoteCategory(payload);
		currentActiveCategoryIndexHandler(null, notesCatagoriesList.length);
	};
	const currentActiveCategoryIndexHandler = (event, newValue) => {
		setCurrentSelectedNoteCategoryIndex(newValue);
	};
	return (
		<Box>
			<Tabs
				value={currentSelectedNoteCategoryIndex}
				onChange={currentActiveCategoryIndexHandler}
				variant='scrollable'
				scrollButtons='auto'
				aria-label='scrollable auto tabs example'
				textColor='secondary'
				indicatorColor='secondary'
			>
				{notesCatagoriesList &&
					notesCatagoriesList.map(tab => {
						return <Tab label={tab.name} key={tab.id} />;
					})}
				<Tab
					icon={<AddIcon />}
					onClick={() => setAddCategoryPopupState(true)}
				/>
			</Tabs>
			<OneFieldFormPopup
				open={shouldShowAddCategoryPopup}
				onCloseHandler={addCategoryPopupHandler}
				validationSchema={validationSchema}
				fieldLabel={'Category'}
					popupHeading={'Save'}
					popupBodyText={
						'To add a category, please enter category name.'
					}
			/>
		</Box>
	);
}
function mapToState(state) {
	const { notesReducers } = state;
	const { notesCatagoriesList, currentSelectedNoteCategoryIndex } =
		notesReducers;
	return {
		notesCatagoriesList,
		currentSelectedNoteCategoryIndex,
	};
}

const mapToDispatch = {
	setCurrentSelectedNoteCategoryIndex:
		notesAction.setCurrentSelectedNoteCategoryIndex,
};
export default connect(mapToState, mapToDispatch)(CategoriesTabList);
CategoriesTabList.propTypes = {
	currentSelectedNoteCategoryIndex: PropTypes.number.isRequired,
	setCurrentSelectedNoteCategoryIndex: PropTypes.func.isRequired,
	notesCatagoriesList: PropTypes.arrayOf(PropTypes.object).isRequired,
};
