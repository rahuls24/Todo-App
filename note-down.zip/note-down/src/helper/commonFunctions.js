import { sort } from 'fast-sort';
import { notesServices } from '../services/notesServices';
import {store} from '../store/store'
export function formatFirebaseErrorMessage(errorMsg = '') {
	if (errorMsg.includes('auth/weak-password'))
		return 'Password should be at least 6 characters';
	if (errorMsg.includes('auth/invalid-email')) return 'Email is not valid.';
	if (errorMsg.includes('auth/wrong-password')) return 'Enter Correct Password'
	if (errorMsg.includes('auth/email-already-in-use')) return 'This email is already register.'
	return 'Something went wrong';
}

export function isOffline() {
	if(navigator && navigator.onLine) return false
	return true
}

export function filterNoteItemsByCategory(noteItemsList, categoryId) {
	return noteItemsList.filter(noteItem => noteItem.category === categoryId);
}
export function filterNoteItemsByState(noteItemsList, state, categoryId, sortBy) {
	const notes = filterNoteItemsByCategory(noteItemsList, categoryId).filter(
		noteItem => noteItem.state === state,
	);
	switch (sortBy) {
		case 'title':
			return sort(notes).asc(note => note.title);
		case 'updatedOn':
			return sort(notes).desc(note => note.updatedOn);
		default:
			return sort(notes).asc(note => note.title);
	}
}
export async function deleteAllCompletedNotesFromActiveCategory() {
	const { notesReducers } = store.getState();
	if(!notesReducers) return 
	const {allNotes,currentSelectedNoteCategoryIndex,notesCatagoriesList} = notesReducers;
	const completedNotesList = filterNoteItemsByState(
		allNotes,
		'completed',
		notesCatagoriesList[currentSelectedNoteCategoryIndex]?.id,
	);
	await notesServices.deleteAllCompletedNotes(completedNotesList);
};